# Retrofit-Android-Basic
This is a simple retrofit android example for github api.

<b>Retrofit-Android-Basic</b>
      Retrofit Beginner Example using Github Api.
      Tutorial on :
      http://themakeinfo.com/2015/04/retrofit-android-tutorial/
      
      Networking in Android can be made easy using Retrofit library.
      Tutorial will start from the beginner setup,how to add retrofit library to the Project ..etc
      
      
